Input API ver. 1.0.3 guide

--Simple